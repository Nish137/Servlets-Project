package com.capgemini.flp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "abc")
public class Order {

	@Id
	@NotEmpty
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "order_Id")
	private int orderid;
	@Column(name = "order_Type")
	@NotEmpty
	private String orderType;
	@Column(name = "product_Id")
	@NotEmpty
	private int productId;
	@Column(name = "product_Name")
	@NotEmpty
	private String productName;
	@Column(name = "product_Name")
	@NotEmpty
	private double product_Price;
	@Column(name = "product_Image")
	@NotEmpty
	private String productImage;
	@Column(name = "product_Quantity")
	@NotEmpty
	private int productQuantity;
	@Column(name = "product_Discount")
	@NotEmpty
	private String productDiscount;
	@Column(name = "customer_email_Id")
	@NotEmpty
	private String customerEmailId;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProduct_Price() {
		return product_Price;
	}

	public void setProduct_Price(double product_Price) {
		this.product_Price = product_Price;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(String productDiscount) {
		this.productDiscount = productDiscount;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int orderid, String orderType, int productId,
			String productName, double product_Price, String productImage,
			int productQuantity, String productDiscount, String customerEmailId) {
		super();
		this.orderid = orderid;
		this.orderType = orderType;
		this.productId = productId;
		this.productName = productName;
		this.product_Price = product_Price;
		this.productImage = productImage;
		this.productQuantity = productQuantity;
		this.productDiscount = productDiscount;
		this.customerEmailId = customerEmailId;
	}
}
