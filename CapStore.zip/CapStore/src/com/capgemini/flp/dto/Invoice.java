package com.capgemini.flp.dto;

import javax.persistence.Entity;

@Entity
public class Invoice {
	private int product_Id;
	private String product_Name;
	private String  product_Description;
	private double product_Rate;
	private int product_Quantity;
	private double product_Discount;
	
	private double total_Amount;
	private double amount;
	private double  amount_Paid;
	
	private double balance_Due;

	public String getProduct_Name() {
		return product_Name;
	}

	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}

	public String getProduct_Description() {
		return product_Description;
	}

	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}

	public double getProduct_Rate() {
		return product_Rate;
	}

	public void setProduct_Rate(double product_Rate) {
		this.product_Rate = product_Rate;
	}

	public int getProduct_Quantity() {
		return product_Quantity;
	}

	public void setProduct_Quantity(int product_Quantity) {
		this.product_Quantity = product_Quantity;
	}

	public double getProduct_Discount() {
		return product_Discount;
	}

	public void setProduct_Discount(double product_Discount) {
		this.product_Discount = product_Discount;
	}

	

	public double getTotal_Amount() {
		return total_Amount;
	}

	public void setTotal_Amount(double total_Amount) {
		this.total_Amount = total_Amount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getAmount_Paid() {
		return amount_Paid;
	}

	public void setAmount_Paid(double amount_Paid) {
		this.amount_Paid = amount_Paid;
	}

	public double getBalance_Due() {
		return balance_Due;
	}

	public void setBalance_Due(double balance_Due) {
		this.balance_Due = balance_Due;
	}

	

	public int getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Invoice(int product_Id, String product_Name,
			String product_Description, double product_Rate,
			int product_Quantity, double product_Discount,
			double product_price, double total_Amount, double amount,
			double amount_Paid, double balance_Due) {
		super();
		this.product_Id = product_Id;
		this.product_Name = product_Name;
		this.product_Description = product_Description;
		this.product_Rate = product_Rate;
		this.product_Quantity = product_Quantity;
		this.product_Discount = product_Discount;
		
		this.total_Amount = total_Amount;
		this.amount = amount;
		this.amount_Paid = amount_Paid;
		this.balance_Due = balance_Due;
	}
	
	
}
