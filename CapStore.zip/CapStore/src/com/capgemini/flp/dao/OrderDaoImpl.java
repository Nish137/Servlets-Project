package com.capgemini.flp.dao;

public class OrderDaoImpl implements OrderDao {

}
