package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Invoice;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.Order;
import com.capgemini.flp.exception.InvoiceException;




@Repository
public class InvoiceDaoImpl implements InvoiceDao {
	@PersistenceContext 
	EntityManager entityManager;
		
		
	

	
		@Override
		public void getInvoice(int productid, int orderid)
				throws InvoiceException {
			entityManager.find(Order.class, orderid);
			entityManager.find(MerchantProduct.class, productid);
			
		
			
		}
		}


