package com.capgemini.flp.service;

public interface MerchantService {

}
