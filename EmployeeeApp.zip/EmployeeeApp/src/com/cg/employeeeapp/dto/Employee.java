package com.cg.employeeeapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee {
	@Id
	@Column(name="id")
	private int empId;
	@NotEmpty(message="Employee Name is Mandatory")
	@Pattern(regexp="[A-Za-z\\s]",message="nmae should contain only Alphabets")
	private String name;
	
	@Max(60)
	@Min(18)
	private  int age;
	private  double salary;
	private String  gender;
	public int getEmpId() {
		return empId;
	}
	public void setEmpid(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

}
