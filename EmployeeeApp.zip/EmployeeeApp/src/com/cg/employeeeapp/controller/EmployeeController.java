package com.cg.employeeeapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeeeapp.dto.Employee;
import com.cg.employeeeapp.exception.EmployeeException;
import com.cg.employeeeapp.service.EmployeeService;
@Controller
public class EmployeeController{
	
	@Autowired
	EmployeeService service;
	@RequestMapping ("/")

	
	public ModelAndView showIndex() throws Exception {
		ModelAndView mv=new ModelAndView("index");
		try{
			List<Employee> employees=service.getEmployees();
			mv.addObject("employees",employees);

		}catch (Exception e){
		 throw new EmployeeException (e.getMessage());
		}
		return mv;
		
	}
	 @RequestMapping("/addEmployee")
	 public String showAdd(Model model){
		 
		 model.addAttribute("employee",new Employee());
		return "add";
		 
	 }
	 @RequestMapping("/add")
  public ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result){
	  ModelAndView mv=null;
	  
	  if(result.hasErrors()){
		  
		  
		  
		  
		    mv=new  ModelAndView("add");
		   mv.addObject("employee",employee);
		   
	  }
	  else{
		   
	  }
	  return mv;
  }
}
