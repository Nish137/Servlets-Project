package com.cg.employeeeapp.dao;

import java.util.List;

import com.cg.employeeeapp.dto.Employee;
import com.cg.employeeeapp.exception.EmployeeException;

public interface EmployeeDao {
	List<Employee> getEmployees() throws EmployeeException;

}
