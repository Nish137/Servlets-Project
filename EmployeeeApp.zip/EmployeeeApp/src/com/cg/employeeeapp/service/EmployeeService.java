package com.cg.employeeeapp.service;

import java.util.List;

import com.cg.employeeeapp.dto.Employee;
import com.cg.employeeeapp.exception.EmployeeException;

public interface EmployeeService {
	List<Employee> getEmployees() throws EmployeeException;

}
