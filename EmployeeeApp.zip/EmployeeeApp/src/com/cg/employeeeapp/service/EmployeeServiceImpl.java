package com.cg.employeeeapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeeeapp.dao.EmployeeDao;
import com.cg.employeeeapp.dto.Employee;
import com.cg.employeeeapp.exception.EmployeeException;
@Transactional
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getEmployees();
	}

}
